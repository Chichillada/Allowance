package com.myapp.allowancecalculator3;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class DetailsActivity extends AppCompatActivity {
    private Button button;
    private Context context;

    public static String EXTRA_CHORE_ID = "choreId";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);


        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.details_fragment_container);

        if (fragment == null) {
            int choreId = getIntent().getIntExtra(EXTRA_CHORE_ID, 1);
            fragment = DetailsFragment.newInstance(choreId);
            fragmentManager.beginTransaction()
                    .add(R.id.details_fragment_container, fragment)
                    .commit();
        }
        /*Dialog dialog = new Dialog(this, android.R.style.Theme_Light_NoTitleBar_Fullscreen);
        View alertView = getLayoutInflater().inflate(R.layout.dialog_chore, null, false);

        button = alertView.findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });*/
    }

    /*public void openDialog () {
        InDialog inDialog = new InDialog();
        inDialog.show(getSupportFragmentManager(), "what");

    }

    public Context myContext (){
        this.context = context;
        return context;

    }*/
}
