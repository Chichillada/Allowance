package com.myapp.allowancecalculator3;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProfileListFragment extends Fragment {

    public interface OnProfileSelectedListener {
        void onProfileSelected(int choreId);
    }

    private OnProfileSelectedListener mListener;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        Toast.makeText(getActivity(), "No state saved", Toast.LENGTH_LONG).show();

        RecyclerView recyclerView = view.findViewById(R.id.chore_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        ProfileAdapter adapter = new ProfileAdapter(ProfileDatabase.getInstance(getContext()).getChores());
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnProfileSelectedListener) {
            mListener = (OnProfileSelectedListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnChoreSelectedListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String profileId = (String) view.getTag();
            mListener.onProfileSelected(Integer.parseInt(profileId));
        }
    };



    private class ProfileHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Chore mChore;

        private TextView mNameTextView;

        public ProfileHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_profile_items, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.profileName);
        }

        public void bind(Chore chore) {
            mChore = chore;
            mNameTextView.setText(mChore.getName());
        }

        @Override
        public void onClick(View view) {
            mListener.onProfileSelected(mChore.getId());
        }
    }

    private class ProfileAdapter extends RecyclerView.Adapter<ProfileHolder> {

        private List<Chore> mChores;

        public ProfileAdapter(List<Chore> chores) {
            mChores = chores;
        }

        @Override
        public ProfileHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ProfileHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ProfileHolder holder, int position) {
            Chore chore = mChores.get(position);
            holder.bind(chore);
        }

        @Override
        public int getItemCount() {
            return mChores.size();
        }
    }
}
