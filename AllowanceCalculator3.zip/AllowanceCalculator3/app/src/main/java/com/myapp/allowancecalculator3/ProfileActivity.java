package com.myapp.allowancecalculator3;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class ProfileActivity extends AppCompatActivity
        implements ProfileListFragment.OnProfileSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toast.makeText(getApplicationContext(),"Hello Javatpoint",Toast.LENGTH_SHORT).show();

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.Main_fragment_container);

        if (fragment == null) {
            fragment = new MainFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.Main_fragment_container, fragment)
                    .commit();
        }
    }

    @Override
    public void onProfileSelected(int profileId) {
        if (findViewById(R.id.details_fragment_container) == null) {
            Intent intent = new Intent(this, ProfileDetailsActivity.class);
            intent.putExtra(ProfileDetailsActivity.EXTRA_PROFILE_ID, profileId);
            startActivity(intent);
        } else {
            Fragment profileFragment = ProfileDetailsFragment.newInstance(profileId);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.details_fragment_container, profileFragment)
                    .commit();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Determine which menu option was chosen
        switch (item.getItemId()) {
            case R.id.Chores:
                toList(1);
                return true;

            case R.id.Profiles:
                toProfiles(2);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void toList(int num) {
        Intent chore = new Intent(ProfileActivity.this, MainActivity.class);
        startActivity(chore);
    }

    private void toProfiles (int numVisible) {
        Intent profile = new Intent(ProfileActivity.this, ProfileActivity.class);
        startActivity(profile);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);

        return true;
    }
}