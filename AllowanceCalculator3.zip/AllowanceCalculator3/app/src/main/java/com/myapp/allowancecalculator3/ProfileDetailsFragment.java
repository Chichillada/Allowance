package com.myapp.allowancecalculator3;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ProfileDetailsFragment extends Fragment implements InDialog.OnInputSelected{

    private Chore mProfile;
    public Button aButton;
    public TextView aText;
    public Button bButton;
    public TextView bText;
    public TextView bText2;
    public Button cButton;
    public TextView cText;
    private static final String TAG = "ProfilesDetailsFragment";
    private String inText = "";

    public static ProfileDetailsFragment newInstance(int profileId) {
        ProfileDetailsFragment fragment = new ProfileDetailsFragment();
        Bundle args = new Bundle();
        args.putInt("profileId", profileId);
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Toast.makeText(getActivity(), "No state saved", Toast.LENGTH_LONG).show();

        int profileId = 1;
        if (getArguments() != null) {
            profileId = getArguments().getInt("profileId");
        }

      mProfile = ProfileDatabase.getInstance(getContext()).getChore(profileId);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toast.makeText(getActivity(), "No state saved", Toast.LENGTH_LONG).show();

        View view = inflater.inflate(R.layout.fragment_profile_details, container, false);

        TextView nameTextView = (TextView) view.findViewById(R.id.profileName);
        nameTextView.setText(mProfile.getName());

        TextView descriptionTextView = (TextView) view.findViewById(R.id.profileDescription);
        descriptionTextView.setText(mProfile.getDescription());

        //TextView description2TextView = (TextView) view.findViewById(R.id.Description3);
        //description2TextView.setText("Completed: " + mProfile.getComplete());

        aButton = (Button) view.findViewById(R.id.pButton);
        aText = (TextView) view.findViewById(R.id.Description3);
        aButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                String currDate = simpleDateFormat.format(new Date());
                aText.setText("Completed: " + currDate);
            }
        });

        bButton = (Button) view.findViewById(R.id.pButton2);
        bText = (TextView) view.findViewById(R.id.profileDescription3);
        bButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bText.setText("Completed: TBD");
            }
        });

        //Dialog dialog = new Dialog(getActivity(), android.R.style.Theme_Light_NoTitleBar_Fullscreen);
        View alertView = getLayoutInflater().inflate(R.layout.fragment_details, null, false);

        cButton = (Button) view.findViewById(R.id.pButton3);
        cText = (TextView) view.findViewById(R.id.profileDescription);
        cButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InDialog dialog = new InDialog();
                dialog.setTargetFragment(ProfileDetailsFragment.this, 1);
                dialog.show(getFragmentManager(), "Dialog");
            }
        });

        return view;
    }

    @Override
    public void sendInput(String str) {
        cText.setText(str);
    }

    @Override
    public void onViewStateRestored( Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);

        String str = "";

        if(savedInstanceState == null){

            Toast.makeText(getActivity(), "No state saved", Toast.LENGTH_LONG).show();
            Log.i(TAG, "TEST");
        }else {
            str = savedInstanceState.getString("Key");
            Toast.makeText(getActivity(), "state restored", Toast.LENGTH_LONG).show();
        }
        bText.setText(str);
    }

    @Override
    public void onSaveInstanceState (Bundle state){
        String cow = bText2.getText().toString();
        super.onSaveInstanceState(state);
        //String save = editTextEditState.getText().toString();
        state.putString("Key", cow);
        Log.i(TAG, "I HAVE BEEN SAVED");
        Toast.makeText(getActivity(), "state saved", Toast.LENGTH_LONG).show();
    }

}