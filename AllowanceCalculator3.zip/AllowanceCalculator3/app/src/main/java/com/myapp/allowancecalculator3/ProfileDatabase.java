package com.myapp.allowancecalculator3;

import android.content.Context;
import android.content.res.Resources;

import java.util.ArrayList;
import java.util.List;

public class ProfileDatabase {
    private static ProfileDatabase sProfileDatabase;
    private List<Chore> mChores;

    public static ProfileDatabase getInstance(Context context) {
        if (sProfileDatabase == null) {
            sProfileDatabase = new ProfileDatabase(context);
        }
        return sProfileDatabase;
    }

    private ProfileDatabase(Context context) {
        mChores = new ArrayList<>();
        Resources res = context.getResources();
        String[] chores = res.getStringArray(R.array.profiles);
        String[] descriptions = res.getStringArray(R.array.descriptions);
        for (int i = 0; i < chores.length; i++) {
            mChores.add(new Chore(i + 1, chores[i], descriptions[i]));
        }
    }

    public List<Chore> getChores() {
        return mChores;
    }

    public Chore getChore(int choreId) {
        for (Chore chore : mChores) {
            if (chore.getId() == choreId) {
                return chore;
            }
        }
        return null;
    }
}
