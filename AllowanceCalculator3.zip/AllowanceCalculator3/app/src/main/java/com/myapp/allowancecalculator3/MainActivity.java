package com.myapp.allowancecalculator3;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.ListFragment;

public class MainActivity extends AppCompatActivity
        implements MainFragment.OnChoreSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.Main_fragment_container);

        if (fragment == null) {
            fragment = new MainFragment();
            fragmentManager.beginTransaction()
                    .add(R.id.Main_fragment_container, fragment)
                    .commit();
        }
    }

    @Override
    public void onChoreSelected(int choreId) {
        if (findViewById(R.id.details_fragment_container) == null) {
            Intent intent = new Intent(this, DetailsActivity.class);
            intent.putExtra(DetailsActivity.EXTRA_CHORE_ID, choreId);
            startActivity(intent);
        } else {
            Fragment choreFragment = DetailsFragment.newInstance(choreId);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.details_fragment_container, choreFragment)
                    .commit();
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.Chores:
                toList(1);
                return true;

            case R.id.Profiles:
                toProfiles(2);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void toList(int num) {
        Intent k = new Intent(this, MainActivity.class);
        startActivity(k);
    }

    private void toProfiles (int numVisible) {
        Intent k = new Intent(this, ProfileActivity.class);
        Toast.makeText(MainActivity.this, "No", Toast.LENGTH_LONG).show();
        startActivity(k);
        this.finish();
    }
}