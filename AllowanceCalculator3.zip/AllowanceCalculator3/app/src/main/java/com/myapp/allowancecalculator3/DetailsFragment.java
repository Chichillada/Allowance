package com.myapp.allowancecalculator3;

import android.app.Dialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DetailsFragment extends Fragment implements InDialog.OnInputSelected{

    private Chore mChore;
    public Button aButton;
    public TextView aText;
    public Button bButton;
    public TextView bText;
    public TextView bText2;
    public Button cButton;
    public TextView cText;
    private static final String TAG = "DetailsFragment";
    private String inText = "";

    public static DetailsFragment newInstance(int choreId) {
        DetailsFragment fragment = new DetailsFragment();
        Bundle args = new Bundle();
        args.putInt("choreId", choreId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(savedInstanceState == null){

        }else {
            //bText2 = savedInstanceState.getTextView("saved");
        }

        int choreId = 1;
        if (getArguments() != null) {
            choreId = getArguments().getInt("choreId");
        }

      mChore = ChoreDatabase.getInstance(getContext()).getChore(choreId);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_details, container, false);

        TextView nameTextView = (TextView) view.findViewById(R.id.choreName);
        nameTextView.setText(mChore.getName());

        TextView descriptionTextView = (TextView) view.findViewById(R.id.choreDescription);
        descriptionTextView.setText(mChore.getDescription());

        //TextView description2TextView = (TextView) view.findViewById(R.id.Description3);
        //description2TextView.setText("Completed: " + mChore.getComplete());

        aButton = (Button) view.findViewById(R.id.button);
        aText = (TextView) view.findViewById(R.id.Description3);
        aButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
                String currDate = simpleDateFormat.format(new Date());
                aText.setText("Completed: " + currDate);
            }
        });

        bButton = (Button) view.findViewById(R.id.button2);
        bText = (TextView) view.findViewById(R.id.Description3);
        bButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bText.setText("Completed: TBD");
            }
        });

        //Dialog dialog = new Dialog(getActivity(), android.R.style.Theme_Light_NoTitleBar_Fullscreen);
        View alertView = getLayoutInflater().inflate(R.layout.fragment_details, null, false);

        cButton = (Button) view.findViewById(R.id.button4);
        cText = (TextView) view.findViewById(R.id.choreDescription);
        cButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                InDialog dialog = new InDialog();
                dialog.setTargetFragment(DetailsFragment.this, 1);
                dialog.show(getFragmentManager(), "Dialog");
            }
        });

        return view;
    }

    @Override
    public void sendInput(String str) {
        cText.setText(str);
    }

    @Override
    public void onViewStateRestored( Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);

        String str = "";

        if(savedInstanceState == null){

            Toast.makeText(getActivity(), "No state saved", Toast.LENGTH_LONG).show();
            Log.i(TAG, "TEST");
        }else {
            str = savedInstanceState.getString("Key");
            Toast.makeText(getActivity(), "state restored", Toast.LENGTH_LONG).show();
        }
        bText.setText(str);
    }

    @Override
    public void onSaveInstanceState (Bundle state){
        String cow = bText2.getText().toString();
        super.onSaveInstanceState(state);
        //String save = editTextEditState.getText().toString();
        state.putString("Key", cow);
        Log.i(TAG, "I HAVE BEEN SAVED");
        Toast.makeText(getActivity(), "state saved", Toast.LENGTH_LONG).show();
    }

}