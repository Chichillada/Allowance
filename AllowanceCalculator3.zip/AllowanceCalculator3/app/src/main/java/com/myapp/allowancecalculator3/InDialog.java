package com.myapp.allowancecalculator3;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.DialogFragment;

public class InDialog extends DialogFragment {
    private String inText = "Dialog";
    private EditText mEditText;
    private TextView mOk, mCancel;
    //private TextView mCancel;
    private static final String TAG = "InDialog";

    public interface OnInputSelected {
        void sendInput (String str);
    }

    public OnInputSelected mOnInputSelected;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle SavedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_chore, container, false);
        mOk = view.findViewById(R.id.okButton);
        mCancel = view.findViewById(R.id.cancelButton);
        mEditText = view.findViewById(R.id.UserText);

        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getDialog().dismiss();
            }
        });

        mOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uInput = "Assigned to: " + mEditText.getText().toString();
                if (!uInput.equals("")) {
                    /*DetailsFragment details = (DetailsFragment) getActivity().getSupportFragmentManager().findFragmentByTag("DetailsFragment");
                    details.cText.setText(uInput);

                }*/
                    mOnInputSelected.sendInput(uInput);
                }

                    getDialog().dismiss();

            }
        });

        return view;
    }

    @Override
    public void onAttach (Context context) {
        super.onAttach(context);
        try{
            mOnInputSelected = (OnInputSelected) getTargetFragment();

        }catch(ClassCastException e){
            Log.e(TAG, "onAttach: ClassCastException: " + e.getMessage());
        }
    }

}

