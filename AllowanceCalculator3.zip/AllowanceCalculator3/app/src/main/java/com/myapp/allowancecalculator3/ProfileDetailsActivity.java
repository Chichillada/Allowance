package com.myapp.allowancecalculator3;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

public class ProfileDetailsActivity extends AppCompatActivity {
    private Button button;
    private Context context;

    public static String EXTRA_PROFILE_ID = "profileId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);


        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentById(R.id.details_fragment_container);

        if (fragment == null) {
            int profileId = getIntent().getIntExtra(EXTRA_PROFILE_ID, 1);
            fragment = ProfileDetailsFragment.newInstance(profileId);
            fragmentManager.beginTransaction()
                    .add(R.id.details_fragment_container, fragment)
                    .commit();
        }
    }
}