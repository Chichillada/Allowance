package com.myapp.allowancecalculator3;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MainFragment extends Fragment {

    public interface OnChoreSelectedListener {
        void onChoreSelected(int choreId);
    }

    private OnChoreSelectedListener mListener;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        Toast.makeText(getActivity(), "chores", Toast.LENGTH_LONG).show();

        RecyclerView recyclerView = view.findViewById(R.id.chore_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        ChoreAdapter adapter = new ChoreAdapter(ChoreDatabase.getInstance(getContext()).getChores());
        recyclerView.setAdapter(adapter);

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnChoreSelectedListener) {
            mListener = (OnChoreSelectedListener) context;
        } else {
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String choreId = (String) view.getTag();
            mListener.onChoreSelected(Integer.parseInt(choreId));
        }
    };



    private class ChoreHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Chore mChore;

        private TextView mNameTextView;

        public ChoreHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_items, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.choreName);
        }

        public void bind(Chore chore) {
            mChore = chore;
            mNameTextView.setText(mChore.getName());
        }

        @Override
        public void onClick(View view) {
            mListener.onChoreSelected(mChore.getId());
        }
    }

    private class ChoreAdapter extends RecyclerView.Adapter<ChoreHolder> {

        private List<Chore> mChores;

        public ChoreAdapter(List<Chore> chores) {
            mChores = chores;
        }

        @Override
        public ChoreHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ChoreHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ChoreHolder holder, int position) {
            Chore chore = mChores.get(position);
            holder.bind(chore);
        }

        @Override
        public int getItemCount() {
            return mChores.size();
        }
    }
}
